# NetFree
INFORMACION 
Estimado cliente, NetFree es el resultado del esfuerzo diario de un equipo profesional nombrado SPARROWSproducciones. 
Este proyecto lo hemos venido desarrollando durante cierto tiempo, fundamentalmente en horario extra laboral. 
Con franqueza debemos decir que nuestra empresa se mantiene gracias a los aportes que representan los pagos de los donativos y las actualizaciones. 
Actualizar significa: 
1. Tener acceso a los últimos paquetes de aplicaciones. 
2. Tener acceso a las últimas correcciones del sistema. 
• Cada día, nuestro equipo de trabajo innova para dar soluciones a los problemas que se presentan. 
• Cada día se implementan mejoras técnicas en el interfaz y complementos del programa, elevando con ello la calidad del servicio. 
Estimado, para tratar temas relacionados con: actualizaciones, descargas, donaciones, mantenimiento personalizado, quejas y sugerencias; 
por favor, diríjase a la siguiente dirección: https://www.facebook.com/sparrowsproducciones. 
En ella encontrará la información y el trato que Ud. se merece. 
